<?php

namespace App\WebSocket;

use Swoft\Http\Message\Server\Request;
use Swoft\Http\Message\Server\Response;
use Swoft\WebSocket\Server\Bean\Annotation\WebSocket;
use Swoft\WebSocket\Server\HandlerInterface;
use Swoole\WebSocket\Frame;
use Swoole\WebSocket\Server;
use JPush\Client as JPush;
use Swoft\Task\Task;
/**
 * Class EchoController
 * @package App\WebSocket
 * @WebSocket("/push")
 */
class EchoController implements HandlerInterface
{
    /**
     * {@inheritdoc}
     */
    public function checkHandshake(Request $request, Response $response): array
    {
        return [0, $response];
    }

    /**
     * @param Server $server
     * @param Request $request
     * @param int $fd
     */
    public function onOpen(Server $server, Request $request, int $fd)
    {
        $server->push($fd, json_encode(['code'=>0,'message'=>'this is websocket']));
    }

    /**
     * @param Server $server
     * @param Frame $frame
     */
    public function onMessage(Server $server, Frame $frame)
    {  // file_put_contents(date('Y-m-d').'_.txt',$frame->data);
        $fopen = fopen(date('Y-m-d').'_'.txt,'a');
        fwrite($fopen,date('Y-m-d H:i:s').'--'.$frame->data.PHP_EOL);
        fclose($fopen);
        $server->push($frame->fd, json_encode(['code'=>0,message=>'i have receive your message-----jpush has been push-'.$frame->data]));
	Task::deliver('sync', 'deliverAsyncPush', [$frame->data], Task::TYPE_ASYNC);
	if(false){
        //后期放到异步任务        
        $app_key1 = '7ca71a91f177770a0c67984b';
        $master_secret1 = '4a81429eee975551e3390832';
        $client = new JPush($app_key1, $master_secret1);
        $client->push()
    	       ->setPlatform('all')
               ->addAllAudience()
               ->setNotificationAlert('烟雾报警')
              // ->setMessage("msg content", 'msg title', 'type', array("key1"=>"value1", "key2"=>"value2"))
               ->send();

        $app_key = 'c72bbced04a907151ce051f9';
        $master_secret = 'dbdf3c35f96acd7b06125df8';
        $client = new JPush($app_key, $master_secret);
        $client->push()
               ->setPlatform('all')
               ->addAllAudience()
               ->setNotificationAlert('烟雾报警')
               ->send();
      }
    }

    /**
     * @param Server $server
     * @param int $fd
     */
    public function onClose(Server $server, int $fd)
    {
        // do something. eg. record log, unbind user ...
    }
}
