<?php
namespace App\Models\Entity;

use Swoft\Db\Model;
use Swoft\Db\Bean\Annotation\Column;
use Swoft\Db\Bean\Annotation\Entity;
use Swoft\Db\Bean\Annotation\Id;
use Swoft\Db\Bean\Annotation\Required;
use Swoft\Db\Bean\Annotation\Table;
use Swoft\Db\Types;

/**
 * @Entity()
 * @Table(name="yjc")
 * @uses      Yjc
 */
class Yjc extends Model
{
    /**
     * @var int $id 
     * @Id()
     * @Column(name="id", type="integer")
     */
    private $id;

    /**
     * @var string $hello 
     * @Column(name="hello", type="string", length=255)
     */
    private $hello;

    /**
     * @var string $world 
     * @Column(name="world", type="string", length=255)
     */
    private $world;

    /**
     * @param int $value
     * @return $this
     */
    public function setId(int $value)
    {
        $this->id = $value;

        return $this;
    }

    /**
     * @param string $value
     * @return $this
     */
    public function setHello(string $value): self
    {
        $this->hello = $value;

        return $this;
    }

    /**
     * @param string $value
     * @return $this
     */
    public function setWorld(string $value): self
    {
        $this->world = $value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getHello()
    {
        return $this->hello;
    }

    /**
     * @return string
     */
    public function getWorld()
    {
        return $this->world;
    }

}
