| Q                   | A
| ------------------- | -----
| Bug report?         | yes/no
| Feature request?    | yes/no
| Swoft version       | x.y.z
| Swoole version      | x.y.z (by `php --ri swoole`)
| PHP version         | x.y.z (by `php -v`)
| Runtime environment | Win10/Mac/CentOS 7/Ubuntu/Docker etc.

**Details**

> Describe what you are trying to achieve and what goes wrong.

```php
// paste output here
```

> Provide minimal script to reproduce the issue

```php
// paste code
```

